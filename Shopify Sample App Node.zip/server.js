const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const request = require("request-promise");
const index = require("./routes/index");
const install = require("./routes/install");
const path = require("path");
const app = express();
const Seller = require("./models/Seller");
const Shopify = require("shopify-api-node");
require('dotenv').config();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

//Enable CORS for all HTTP methods
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE, OPTIONS");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});
const config = require("./config/index");
const mongoose = require("mongoose");

mongoose.Promise = global.Promise;
// Connecting to the database
mongoose
  .connect(process.env.MONGODB_URI, {
    useNewUrlParser: true, useUnifiedTopology: true
  })
  .then(() => {
    console.log("Successfully connected to the database");
  })
  .catch((err) => {
    console.log("Could not connect to the database. Exiting now...", err);
    process.exit();
  });

console.log(config.SHOPIFY_API_KEY);
app.use("/", index);
app.use("/install", install);

app.use(express.static(path.join(__dirname, "./react-app")));

const port = process.env.PORT || 8081;
app.listen(port, 'localhost');
console.log('Server running at http://localhost:'+port);
