module.exports = {
    //url: "mongodb+srv://MyUser:Vgroup65@cluster0-bzhc7.mongodb.net/sample_airbnb?retryWrites=true&w=majority",
    url: "mongodb://Ann_Quick_App:AnnQUICK%242021_2020@app.anncode.com:27017/quickview?authSource=admin&readPreference=primary"
 //serverport: 3000 
}