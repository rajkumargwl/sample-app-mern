const mongoose = require('mongoose');


const Seller = mongoose.Schema({
    accessToken: String,
    MyShopifyDomain: String,
    Host:String,
    ShopDomain: String,
    ShopName: String,
    Email: String,
    UserName: String,
    InstallStatus: Boolean,
    installDate:{ type: Date, default: new Date()},
    UnInstallDate: Date,
    CurrentTheme: Number,
    IsAppEnable: Boolean,
    nonce: String,
    chargeId:String,
    scriptTagId:Number,
    installHistory : [{chargeDate:{type:Date,default:new Date()},chargeId:String, uninstallDate: Date }],
    shopDetails:{},
},{collection :'Seller'});

module.exports = mongoose.model('Seller', Seller);