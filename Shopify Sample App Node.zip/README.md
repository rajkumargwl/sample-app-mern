# Sample Shopify Node App

## Credentials to update
### env :
### SHOPIFY_API_KEY  -> Partners public app API key
### SHOPIFY_API_SECRET_KEY -> Partners public app Secret key
### MONGODB_URI -> Database connection string

### config/index.js :
### TESTCHARGE -> Wheather to set a test charge of the app
### TRIALDAYS -> Trial days of the app
### PRICE -> Price of the app