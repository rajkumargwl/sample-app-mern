module.exports = {
  APP_URI: 'https://2ee8-103-15-66-210.ngrok.io'
};
