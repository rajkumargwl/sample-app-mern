const env = process.env.NODE_ENV;
const production = require('./production');
const development = require('./development');
require('dotenv').config();
// /* Live Server Anncode */
const APIKEY = process.env.SHOPIFY_API_KEY;
const APISECRET = process.env.SHOPIFY_API_SECRET_KEY;

// /* LocalHost Loacl */
// const APIKEY = '';
// const APISECRET = '';
// const LOCALSHOPNAME = 'example.myshopify.com'

// You should put any global variables in here.
const config = {
  SHOPIFY_API_KEY: process.env.SHOPIFY_API_KEY,
  SHOPIFY_SHARED_SECRET: APISECRET,
  APP_NAME: 'Basic App',
  TESTCHARGE:'true',
  TRIALDAYS: 15,
  PRICE: 10.00,
  APP_STORE_NAME: 'test',
  APP_SCOPE: 'read_themes,write_themes',
  DATABASE_NAME: 'test',
  DATABASE_URL: process.env.MONGODB_URI
};


if (env !== 'PRODUCTION') {
  module.exports = Object.assign({}, config, development);
} else {
  module.exports = Object.assign({}, config, production);
}
