const fetch = require("node-fetch");
const config= require('../config/index')
const getSubscriptionUrl = async (res,UserDays, accessToken, shop, redirectUrl) => {
var trialDays = config.TRIALDAYS;
if(UserDays>config.TRIALDAYS){
 trialDays = trialDays - config.TRIALDAYS;
} else {
  trialDays = trialDays - UserDays;
}
  const query = JSON.stringify({
    query: `mutation {
      appSubscriptionCreate(
          name: "Basic App Plan"
          returnUrl: "${redirectUrl}"
          test: ${config.TESTCHARGE}
          trialDays: ${trialDays}
          lineItems: [
          {
            plan: {
              appRecurringPricingDetails: {
                  price: { amount: ${config.PRICE}, currencyCode: USD }
              }
            }
          }
          ]
        ) {
            userErrors {
              field
              message
            }
            confirmationUrl
            appSubscription {
              id
            }
        }
    }`,
  });

  const response = await fetch(
    `https://${shop}/admin/api/2021-07/graphql.json`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Shopify-Access-Token": accessToken,
      },
      body: query,
    }
  );

  const responseJson = await response.json();
  const confirmationUrl =
    responseJson.data.appSubscriptionCreate.confirmationUrl;
  res.cookie("chargeShop", shop, {
    maxAge: 3000000,
    path: "/;samesite=none;secure;",
  });
  return res.redirect(confirmationUrl);
};

module.exports = getSubscriptionUrl;
