/**
 * ./routes/webhooks.js
 * This is where you'll set up any webhook endpoints you plan on using. This includes the middleware
 * to check if a request from a webhook is legitemate.
 */
const express = require('express');
const verifyWebhook = require('../middleware').verifyWebhook;
const Seller = require('../models/Seller');
// const Shop = require('../models/Shop');
const router = express.Router();

router.get('/appuninstall', verifyWebhook , (req, res) => {
  console.log(req.params);
  console.log('This app is uninstalled');
  // This is where you should do something with your webhooks. Filter by Topic etc.
  return res.sendStatus(200);
});

// Shop Redact
router.get('/shopRedact',(req,res) => {
  console.log(req.params);
  console.log('Shop Redact');
  return res.sendStatus(200);
});

//customers redact
router.get('/customersRedact',(req,res) => {
  console.log(req.params);
  console.log('customers Redact');
  return res.sendStatus(200);
});

// customers data_request
router.get('/dataRequest',(req,res) => {
  console.log(req.params);
  console.log('customers data request');
  return res.sendStatus(200);
});
module.exports = router;
