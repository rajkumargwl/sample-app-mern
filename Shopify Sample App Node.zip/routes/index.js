const express = require("express");
const verifyOAuth = require("../helpers").verifyOAuth;
const getSubscriptionUrl2 = require("./getSubscriptionUrl2");

const mongoose = require("mongoose");
const config = require("../config/index");
let fs = require("fs");
const Shop = require("../models/Seller");
const ShopifyService = require("shopify-api-node");

const router = express.Router();
var _query = "";

router.get("/", (req, res, next) => {
  _query = Object.keys(req.query)
    .map((key) => `${key}=${req.query[key]}`)
    .join("&");

  if (req.query.shop) {
    Shop.findOne(
      { MyShopifyDomain: req.query.shop},
      async (err, shop) => {
        if (!shop) {
          return res.redirect(`/install/?${_query}`);
        } else if(!shop.accessToken) {
          await Shop.deleteOne({MyShopifyDomain: req.query.shop});
          return res.redirect(`/install/?${_query}`);
        }
        const _shopify = ShopifyService({ shopName: shop.MyShopifyDomain, accessToken: shop.accessToken });
        var isAppSuccess = false;
       try {
        var t =await _shopify.shop.get();
        isAppSuccess = true;
       } catch(e) {
        isAppSuccess = false;
       }
        if(!shop.InstallStatus && isAppSuccess){
          var tempDays = 0;
        var diffDays = 0;
        var tempDiffDays =0;
        if(shop.installHistory != null){
          for(var i=0; i<shop.installHistory.length; i++){
            if(shop.installHistory[i].uninstallDate != null){
            var tempInstallDate = shop.installHistory[i].chargeDate;
            var tempUninstalldate = shop.installHistory[i].uninstallDate;
            const diffTime = Math.abs(tempInstallDate - tempUninstalldate);
            diffDays = Math.ceil(diffTime / (1000 *3600 *24));
            tempDiffDays += diffDays;
            }
          }
          tempDays += tempDiffDays
        }
          const charge_ = await getSubscriptionUrl2(
            res,
            tempDays,
            shop.accessToken,
            req.query.shop,
            `${config.APP_URI}/install/callback`
          );
          res.writeHead(200, {
            "Content-Type": "text/html",
          });
          //build file calling
          fs.readFile("./htmlfile/planredirect.html", null, function (error, data) {
            try{
              var _Html = data.toString();
            if (error) {
              res.writeHead(404);
              res.write("Whoops! File not found!");
            } else {
              var _Html = data.toString();
              var _newHtml = _Html.replace("top_url", charge_);
              res.write(_newHtml);
            }
            res.write(_newHtml);
            res.end();
            }
            catch(e){
              console.log(e);
            }
          });

        }
         if(shop.accessToken == "undefined" || shop.accessToken == null) {
            if(shop.MyShopifyDomain){
                return res.redirect(`/install/?${_query}`);
              }
         }
         
          const shopify = new ShopifyService({
            shopName: shop.MyShopifyDomain,
            accessToken: shop.accessToken,
          });

        try {
          await shopify.shop.get();
        } catch (err) {
          return res.redirect(`/install/?${_query}`);
        }

        if (verifyOAuth(req.query)) {

          //  var shopObject = {};
          //  shopObject.key=config.SHOPIFY_API_KEY;
          //  shopObject.shop=shop.MyShopifyDomain;
          //  shopObject.shopId=shop._id;
          //  shopObject.host=config.APP_URI;
          //  res.cookie('shopData',JSON.stringify(shopObject),{maxAge: 300000,path:'/;samesite=none;secure;'});

          res.writeHead(200, {
            "Content-Type": "text/html",
          });
          //build file calling
          fs.readFile("./react-app/index.html", null, function (error, data) {
            if (error) {
              res.writeHead(404);
              res.write("Whoops! File not found!");
            } else {
              var _Html = data.toString();
              var _newHtml = _Html
                .replace("testshopurl", shop.MyShopifyDomain)
                .replace("testshopid", shop._id)
                .replace("testhost", config.APP_URI)
                .replace("testapikey", config.SHOPIFY_API_KEY);
              res.write(_newHtml);
            }
            res.end();
          });
        }
      }
    );
  } else {
    return res.json({ message: "unauthorize request" });
  }
});

router.get("/error", (req, res) =>
  res.render("error", { message: "Something went wrong!" })
);

module.exports = router;
