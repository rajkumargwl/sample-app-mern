const express = require("express");
const Shop = require("../models/Seller");
const Shopify = require("shopify-node-api");
const ShopifyService = require("shopify-api-node");
const config = require("../config/index");
const generateNonce = require("../helpers").generateNonce;
const router = express.Router();
const getSubscriptionUrl = require("../routes/getSubscriptionUrl");
let fs = require("fs");
const Seller = require("../models/Seller");

router.get("/", (req, res) => {
  const shopName = req.query.shop;
  const nonce = generateNonce();
  const query = Shop.findOne({ MyShopifyDomain: shopName }).exec();
  // const shopAPI = new Shopify({
  //   shop: shopName,
  //   shopify_api_key: config.SHOPIFY_API_KEY,
  //   shopify_shared_secret: config.SHOPIFY_SHARED_SECRET,
  //   shopify_scope: config.APP_SCOPE,
  //   nonce,
  //   redirect_uri: `${config.APP_URI}/install/charge`,
  // });
  // const redirectURI = shopAPI.buildAuthURL();
  var redURI = function(){
    var auth_url = 'https://' + shopName;
    auth_url += "/admin/oauth/authorize?";
    auth_url += "client_id=" + config.SHOPIFY_API_KEY;
    auth_url += "&scope=" + config.APP_SCOPE;
    auth_url += "&redirect_uri=" + `${config.APP_URI}/install/charge`;
    auth_url += "&state=" + nonce;
    return auth_url;
  }

  const redirectURI = redURI();
  
  

  query.then((response) => {
    let save;
    const shop = response;
    if (!shop) {
      save = new Shop({
        MyShopifyDomain: shopName,
        nonce,
        InstallStatus: false,
      }).save();
    } else {
      shop.MyShopifyDomain = shopName;
      shop.nonce = nonce;
      shop.InstallStatus = false;
      save = shop.save();
    }

    return save.then(() => res.redirect(redirectURI));
  });
});

router.get("/charge", (req, res) => {
  const params = req.query;
  const query = Shop.findOne({ MyShopifyDomain: params.shop }).exec();
  query.then((result) => {
    const shop = result;
    const shopAPI = new Shopify({
      shop: params.shop,
      shopify_api_key: config.SHOPIFY_API_KEY,
      shopify_shared_secret: config.SHOPIFY_SHARED_SECRET,
      nonce: shop.nonce,
    });
    shopAPI.exchange_temporary_token(params, (error, data) => {
      if (error) {
        res.redirect("/error");
      }

      shop.accessToken = data.access_token;
      // shop.isActive = true;
      shop.save(async (saveError) => {
        if (saveError) {
          console.log("Cannot save shop: ", saveError);
          res.redirect("/error");
        }
        
        var tempDays = 0;
        var diffDays = 0;
        var tempDiffDays =0;
        if(shop.installHistory != null){
          for(var i=0; i<shop.installHistory.length; i++){
            if(shop.installHistory[i].uninstallDate != null){
            var tempInstallDate = shop.installHistory[i].chargeDate;
            var tempUninstalldate = shop.installHistory[i].uninstallDate;
            const diffTime = Math.abs(tempInstallDate - tempUninstalldate);
            diffDays = Math.ceil(diffTime / (1000 *3600 *24));
            tempDiffDays += diffDays;
            }
          }
          tempDays += tempDiffDays;
        }

        await getSubscriptionUrl(
          res,
          tempDays,
          data.access_token,
          params.shop,
          `${config.APP_URI}/install/callback`
        );
      });
    });
  });
});

router.get("/callback", async (req, res) => {

  const params = req.query;

  let shopUrl = '';
  let newtemp = req.query.shop
  //hardcoded
  try{
    if(req.headers.cookie != null){
      shopUrl = req.headers.cookie.split("chargeShop=")[1];
      if(shopUrl.includes('comm100')){
        shopUrl = shopUrl.slice(0, shopUrl.indexOf(';'));
      }
    }
    else{
      shopUrl = req.headers.cookie.chargeShop;
      if(shopUrl.includes('comm100')){
        shopUrl = shopUrl.slice(0, shopUrl.indexOf(';'));
      }
    }
  }
  catch(e){
    console.log(e);
    try{
    shopUrl = req.headers.cookie.split("=")[1];
    if(shopUrl.includes('comm100')){
      shopUrl = shopUrl.slice(0, shopUrl.indexOf(';'));
    }
  } catch(err) {
    shopUrl = newtemp;
  }
  }
  
  // const query = Shop.findOne({MyShopifyDomain: shopUrl }).exec(async function(err, shop) {
  var shop = await Shop.findOne({ MyShopifyDomain: shopUrl }).exec();
  if (!shop) {
    return res.redirect(`/install/?shop=${shopUrl}`);
  }

  const shopify = new ShopifyService({
    shopName: shop.MyShopifyDomain,
    accessToken: shop.accessToken,
  });

  let chargeData = await shopify.recurringApplicationCharge.get(
    parseInt(params.charge_id)
  );
  if (chargeData.status != "active") {
    return res.redirect(`/install/?shop=${shopUrl}`);
  }
  var inFlag = false;
  if (chargeData.status == "active" && params.hmac) {
    inFlag = true;

    shop.InstallStatus = true;
    shop.save();

    res.writeHead(200, { "Content-Type": "text/html" });
    fs.readFile("./react-app/index.html", null, function (error, data) {
      if (error) {
        res.writeHead(404);
        res.write("Whoops! File not found!");
      } else {
        var _Html = data.toString();

        var _newHtml = _Html
          .replace("testshopurl", shop.MyShopifyDomain)
          .replace("testshopid", shop._id)
          .replace("testhost", config.APP_URI)
          .replace("testapikey", config.SHOPIFY_API_KEY);
        res.write(_newHtml);
      }
      return res.end();
    });
  }

  if (chargeData.status == "active" && inFlag == false) {

    shop.InstallStatus = true;
    shop.save();
    let _shopDetails = await shopify.shop.get({
      fields:
        "id,myshopify_domain,plan_name,shop_owner,customer_email,timezone,name,email,currency,domain,province,country_name,country_code,address1,zip,city,phone",
    });

    shop.shopDetails = _shopDetails;
    shop.Host = _shopDetails.domain;
    shop.isActive = true;
    shop.chargeId = params.charge_id;

    var isObjNull = false;
    
    if(shop.installHistory.length>0){
      for(var i=0; i<shop.installHistory.length; i++){
        var tempCurrentDate  = new Date();
        var tempDay = tempCurrentDate.getDate();
        var tempMonth = tempCurrentDate.getMonth() + 1;
        var tempYear = tempCurrentDate.getFullYear();
        var currentDate = tempDay + "-" + tempMonth+ "-" + tempYear;
        var temp =  shop.installHistory[i].chargeDate;
        var tempChargeDay = temp.getDate();
        var tempChargeMonth = temp.getMonth() + 1;
        var tempChargeYear = temp.getFullYear();
        var myChrageDate = tempChargeDay + "-" + tempChargeMonth + "-" + tempChargeYear;
       
        if(currentDate == myChrageDate){
          isObjNull = false;
          var tempId = shop.installHistory[i]._id;
          var myquery = {
            MyShopifyDomain: shop.MyShopifyDomain,
            installHistory: { $elemMatch: { _id: tempId } },
          };
          var newvalues = { $set: { "installHistory.$.chargeDate": new Date(),
           "installHistory.$.chargeId": params.charge_id } };
          await Seller.updateOne(myquery, newvalues);
        } else {
          isObjNull = true;
        }
      } 
    } else {
      shop.installHistory.addToSet({
      chargeId: params.charge_id,
      chargeDate: new Date(),
    });
  }

  if(isObjNull){
    shop.installHistory.addToSet({
      chargeId: params.charge_id,
      chargeDate: new Date(),
    });
  }
  // shop.save();
  
    
    shop.save(async (saveError) => {
      if (saveError) {
        console.log("Cannot save shop: ", saveError);
        return res.redirect("/error");
      }

      //  buildWebhook('app/uninstalled',`${config.APP_URI}/webhook?shop=${shopUrl}`);
      try {
        var _webhook = {
          topic: "app/uninstalled",
          address: `${config.APP_URI}/webhook/appuninstall?shop=${shopUrl}`,
          format: "json",
        };
        await shopify.webhook.create(_webhook);
      } catch (e) {
        console.log(e);
        console.log("error in created webhook ");
      }

      res.writeHead(200, { "Content-Type": "text/html" });
      fs.readFile("./react-app/index.html", null, function (error, data) {
        if (error) {
          res.writeHead(404);
          res.write("Whoops! File not found!");
        } else {
          var _Html = data.toString();
          var _newHtml = _Html
            .replace("testshopurl", shop.MyShopifyDomain)
            .replace("testshopid", shop._id)
            .replace("testhost", config.APP_URI)
            .replace("testapikey", config.SHOPIFY_API_KEY);
          res.write(_newHtml);
        }

        return res.end();
      });
    });
  }
} );

module.exports = router;