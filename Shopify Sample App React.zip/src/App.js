import React, {useState } from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
import "./App.css";
import Headers from "./components/Header";
import Setting from "./components/Settings";
import { Fragment } from "react";
const App = (props) => {
  const [currentPlan, setCurrentPlan] = useState("");

  return (
    <Fragment>
      <Router>
        <Headers />
        <Switch>
          <Route exact path="/">
            <Redirect to="/Setting" />
          </Route>

          <Route path="*" exact={true} component={Setting}></Route>
        </Switch>
      </Router>
    </Fragment>
  );
};

export default App;
