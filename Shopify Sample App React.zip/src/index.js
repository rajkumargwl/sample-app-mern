import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";
import translations from "@shopify/polaris/locales/en.json";
import App from "./App";
import * as serviceWorker from "./serviceWorker";
import { AppProvider } from "@shopify/polaris";
import "@shopify/polaris/styles.css";
import { Provider, ResourcePicker } from "@shopify/app-bridge-react";
const config = {
  apiKey: window._globalApiKey,
  shopOrigin: window._globalShopUrl,
  forceRedirect: true,
};

//live server (With App Bridge)
ReactDOM.render(
  <BrowserRouter>
    <Provider config={config}>
      <AppProvider i18n={translations}>
        <App />
        {/* <ResourcePicker resourceType="Product" open /> */}
      </AppProvider>
    </Provider>
  </BrowserRouter>,
  document.getElementById("root")
);

//localhost (Without App Bridge)
// ReactDOM.render(
//   <BrowserRouter>
//     <AppProvider i18n={translations}>
//       <App />
//     </AppProvider>
//   </BrowserRouter>,
//   document.getElementById("root")
// );

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
