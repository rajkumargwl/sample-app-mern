import React, { useCallback, useState, useEffect } from "react";

function Settings() {
 

  return (
    <div>
     Welcome
    </div>
  );
}

export default Settings;
