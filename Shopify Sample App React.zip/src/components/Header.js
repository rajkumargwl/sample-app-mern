import React, { useCallback, useState } from "react";
import { Link, useHistory } from "react-router-dom";
require("./css/customStyle.css");

export default function Header() {
  const history = useHistory();
  const [headerClass1, setheaderClass1] = useState("Setting");
  // const [headerClass2, setheaderClass2] = useState(false);
  // const [headerClass3, setheaderClass3] = useState(false);
  // const [headerClass4, setheaderClass4] = useState(false);
  // const [headerClass5, setheaderClass5] = useState(false);

  const _Setting = () => {
    setheaderClass1("Setting");
    history.push("/Setting");
  };
  return (
    <div className="setting-header">
      <button
        id="headerSettings"
        className={headerClass1 == "Setting" ? "ActiveHeaderButton" : ""}
        onClick={_Setting}
      >
        Settings
      </button>
    </div>
  );
}
