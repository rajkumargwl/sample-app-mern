# Sample Shopify React App
 
### src/config.json :
### APIURL -> Url of the server